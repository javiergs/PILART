using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.ARFoundation;

public class SpawnAnchorFromRayInteract : MonoBehaviour
{
    public UnityEngine.XR.Interaction.Toolkit.Interactors.XRRayInteractor rayInteractor;
    public ARAnchorManager anchorManager;

    void Start()
    {
        rayInteractor.selectEntered.AddListener(SpawnAnchor);
    }

    public void SpawnAnchor(BaseInteractionEventArgs args)
    {
        if (rayInteractor.TryGetCurrent3DRaycastHit(out RaycastHit hit))
        {
            Pose hitPose = new Pose(hit.point, Quaternion.LookRotation(hit.normal));
            ARAnchor anchor = anchorManager.AddAnchor(hitPose);
            if (anchor != null)
            {
                // Successfully added an anchor
                Debug.Log("Anchor added successfully at: " + hitPose.position);
            }
            else
            {
                // Failed to add an anchor
                Debug.LogError("Failed to add anchor.");
            }
        }
        else
        {
            Debug.LogError("Raycast did not hit any surfaces.");
        }
    }
}
